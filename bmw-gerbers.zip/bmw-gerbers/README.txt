bmw.cmp = top layer copper
bmw.sol = bottom layer copper
bmw.plc = top silkscreen and outline
bmw.stc = top soldermask
bmw.sts = bottom soldermask
bmw.drd = excellon drill file

Part Number: BMW
Revision: 1
